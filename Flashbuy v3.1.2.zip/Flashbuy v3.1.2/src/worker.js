// ══════════════════════════════════════════════════════════════
var FB_API_URL = "https://script.google.com/macros/s/AKfycbwVyhWEs9q7v78-prSD-IHNO5du8D-IJ0nU7EQjLMvejRgh6kO_ng2hGpEg0oIMZ6T9vg/exec";
// ══════════════════════════════════════════════════════════════

var FB_SECRET = "FB2026NovaDev";

function fbDecrypt(encoded, key) {
  var secret = FB_SECRET + key;
  var bytes = atob(encoded);
  var result = "";
  for (var i = 0; i < bytes.length; i++) {
    result += String.fromCharCode(bytes.charCodeAt(i) ^ secret.charCodeAt(i % secret.length));
  }
  return JSON.parse(result);
}

function getDeviceId(callback) {
  chrome.storage.local.get(["fb_device_id"], function(d) {
    if (d.fb_device_id) {
      callback(d.fb_device_id);
    } else {
      var id = "FB-" + Date.now().toString(36) + "-" + Math.random().toString(36).substring(2, 10);
      chrome.storage.local.set({ fb_device_id: id }, function() {
        callback(id);
      });
    }
  });
}

function prefetchOps() {
  chrome.storage.sync.get(["fb_license"], function(cfg) {
    var key = (cfg.fb_license || "").toUpperCase();
    if (!key) return;

    getDeviceId(function(deviceId) {
      var url = FB_API_URL + "?key=" + encodeURIComponent(key) + "&action=payload";
      if (deviceId) url += "&device=" + encodeURIComponent(deviceId);

      fetch(url)
        .then(function(r) { return r.json(); })
        .then(function(res) {
          if (res.status === "valid" && res.ops) {
            try {
              var ops = fbDecrypt(res.ops, key);
              chrome.storage.local.set({
                fb_ops: JSON.stringify(ops),
                fb_valid: true,
                fb_expiry: res.expiry,
                fb_remaining: res.remaining,
                fb_lic_check_time: Date.now()
              });
              chrome.storage.sync.set({ fb_lic_data: JSON.stringify(res) });
            } catch (e) {}
          } else {
            // Licentie ongeldig / verlopen / verkeerd apparaat: cache wissen
            chrome.storage.local.set({ 
              fb_valid: false,
              fb_lic_check_time: Date.now()
            });
            chrome.storage.local.remove(["fb_ops"]);
            // Update sync data zodat popup correcte status toont
            chrome.storage.sync.set({ fb_lic_data: JSON.stringify(res || { status: "invalid" }) });
          }
        })
        .catch(function() {});
    });
  });
}

chrome.runtime.onInstalled.addListener(function() {
  chrome.storage.sync.set({ fb_api: FB_API_URL, fb_method: "PAYPAL" });
  chrome.storage.local.remove(["fb_lic_check_time"]);
  setTimeout(prefetchOps, 2000);
});

chrome.runtime.onStartup.addListener(function() {
  chrome.storage.sync.set({ fb_api: FB_API_URL });
  // Forceer licentiecheck bij elke browser-start
  chrome.storage.local.remove(["fb_lic_check_time"]);
  // Sync paused status naar local zodat autocheckout.js direct kan lezen
  chrome.storage.sync.get(["fb_paused"], function(d) {
    chrome.storage.local.set({ fb_paused: !!d.fb_paused });
  });
  prefetchOps();
});

// ── QuickNav: detecteer add-to-cart PATCH via webRequest ────
chrome.webRequest.onCompleted.addListener(
  function(details) {
    if (details.method !== "PATCH") return;
    if (details.url.indexOf("api.ibood.io/basket/my-basket") === -1) return;
    if (details.statusCode < 200 || details.statusCode >= 300) return;

    chrome.storage.local.get(["fb_paused", "fb_buying", "fb_buying_time"], function(d) {
      if (d.fb_paused) return;

      var buyingRecent = d.fb_buying &&
        d.fb_buying_time &&
        (Date.now() - d.fb_buying_time) < 10000;

      if (!buyingRecent) return;

      chrome.storage.local.set({ fb_buying: false });

      // Kleine delay (300ms) zodat server basket kan bijwerken
      setTimeout(function() {
        chrome.tabs.get(details.tabId, function(tab) {
          if (!tab || !tab.url) return;
          if (tab.url.indexOf("/basket") !== -1 ||
              tab.url.indexOf("/checkout") !== -1) return;
          var isBE = tab.url.indexOf("/s-be") !== -1;
          var checkoutUrl = isBE
            ? "https://www.ibood.com/basket/nl/s-be/checkout"
            : "https://www.ibood.com/basket/nl/s-nl/checkout";
          chrome.tabs.update(details.tabId, { url: checkoutUrl });
        });
      }, 300);
    });
  },
  { urls: ["*://api.ibood.io/basket/my-basket*"] }
);

var lastTab = 0;

chrome.tabs.onUpdated.addListener(function(tabId, info, tab) {
  if (!tab.url || tab.url.indexOf("ibood.com") === -1) return;

  if (tab.url.indexOf("/checkout") !== -1 && info.status === "complete") {
    // Check of ops gecached zijn
    chrome.storage.local.get(["fb_valid", "fb_ops"], function(d) {
      if (d.fb_valid && d.fb_ops) {
        // Cache OK → direct injecteren
        chrome.scripting.executeScript({ target: { tabId: tabId }, files: ["src/autocheckout.js"] })
          .catch(function(e) {});
      } else {
        // Cache leeg → eerst prefetchen, dan injecteren
        prefetchOps();
        setTimeout(function() {
          chrome.scripting.executeScript({ target: { tabId: tabId }, files: ["src/autocheckout.js"] })
            .catch(function(e) {});
        }, 3000);
      }
    });
  }
});
