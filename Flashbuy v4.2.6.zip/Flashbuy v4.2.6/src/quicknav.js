// FlashBuy – quicknav.js v4.2.0
// Box Mode flow (volledig in content script):
//   1. Normaal pollen elke 2s → lees item.end
//   2. 8s voor einde → rapid poll 200ms
//   3. Nieuw item.id → direct PATCH vanuit content script (juiste origin + cookies)
//   4. worker.js detecteert PATCH via webRequest → checkout redirect

(function() {
  "use strict";

  if (window._fbQuickNavRunning) return;
  window._fbQuickNavRunning = true;

  if (window.location.href.indexOf("/basket") !== -1 ||
      window.location.href.indexOf("/checkout") !== -1) return;

  function _l(m) { console.log("[FlashBuy nav] " + m); }

  // ── API constanten ─────────────────────────────────────────
  var LIVE_URL   = "https://api.ibood.io/event/events/live";
  var BASKET_URL = "https://api.ibood.io/basket/my-basket";
  var IBEX = {
    "Accept":         "application/json, text/plain, */*",
    "Ibex-Language":  "nl",
    "Ibex-Shop-Id":   "52e47183-4a24-57fa-bef0-f82972e1f5ac",
    "Ibex-Tenant-Id": "eafb3ef2-e1ba-4f01-b67a-b0447bea74eb"
  };

  // ── State ──────────────────────────────────────────────────
  var _lastItemId       = null;
  var _normalTimer      = null;
  var _rapidTimer       = null;
  var _rapidScheduled   = null;
  var _rapidActive      = false;
  var _buyingInProgress = false;

  // ── 1. Koopknop detectie (manuele modus) ───────────────────
  function _isBuyButton(el) {
    if (!el) return false;
    var cls = el.className || "";
    if (cls.indexOf("Offer_btnMain") !== -1) return true;
    if (cls.indexOf("btnMain") !== -1) return true;
    var txt = (el.textContent || "").toLowerCase().trim();
    if (txt === "ik neem er 1!" || txt === "ik neem er 1") return true;
    if (txt === "nu afrekenen") return true;
    if (txt === "bestellen" && cls.indexOf("orange") !== -1) return true;
    return false;
  }

  function _listenForBuyClick() {
    document.addEventListener("click", function(e) {
      var el = e.target;
      for (var i = 0; i < 5; i++) {
        if (!el) break;
        if (_isBuyButton(el)) {
          _l("Koopknop geklikt: " + (el.textContent || "").trim());
          chrome.storage.local.set({ fb_buying: true, fb_buying_time: Date.now() });
          return;
        }
        el = el.parentElement;
      }
    }, true);
    _l("Luistert naar koopknop...");
  }

  // ── 2. Box Mode: filter check + PATCH ──────────────────────
  function _tryBuy(item) {
    if (_buyingInProgress) return;

    chrome.storage.local.get(["fb_paused", "fb_box_mode", "fb_box_filter"], function(d) {
      if (d.fb_paused || !d.fb_box_mode) return;

      // Filter check
      var filter = (d.fb_box_filter || "").toLowerCase().trim();
      if (filter) {
        var slugMatch  = (item.slug  || "").toLowerCase().indexOf(filter) !== -1;
        var titleMatch = (item.title || "").toLowerCase().indexOf(filter) !== -1;
        if (!slugMatch && !titleMatch) {
          _l("Overgeslagen (filter '" + filter + "'): " + item.title);
          return;
        }
      }

      _buyingInProgress = true;
      _l("✓ KOOP: " + item.title + " — basket ophalen...");
      _stopRapid();
      chrome.storage.local.set({ fb_buying: true, fb_buying_time: Date.now() });

      // Stap 1: haal de auth token op via live-call
      chrome.storage.local.get(["fb_ibood_patch_headers"], function(s) {
        var captured = {};
        try { captured = JSON.parse(s.fb_ibood_patch_headers || "{}"); } catch(e) {}

        var authToken = null;
        Object.keys(captured).forEach(function(k) {
          if (k.toLowerCase() === "authorization") authToken = captured[k];
        });

        var headers = {
          "Accept":         "application/json, text/plain, */*",
          "Ibex-Language":  "nl",
          "Ibex-Shop-Id":   "52e47183-4a24-57fa-bef0-f82972e1f5ac",
          "Ibex-Tenant-Id": "eafb3ef2-e1ba-4f01-b67a-b0447bea74eb"
        };
        if (authToken) headers["Authorization"] = authToken;

        // Stap 2: GET huidig basket
        fetch(BASKET_URL, { method: "GET", headers: headers })
          .then(function(r) { return r.json(); })
          .then(function(basketData) {
            var basket = basketData && basketData.data && basketData.data.items && basketData.data.items[0];
            if (!basket) {
              _l("Basket ophalen mislukt");
              chrome.storage.local.set({ fb_buying: false });
              _buyingInProgress = false;
              return;
            }

            _l("Basket opgehaald — item toevoegen: " + item.title);

            // Stap 3: voeg nieuw item toe aan basket items array
            // iBood verwacht integers voor classicOfferId en classicProductId
            var newItem = {
              classicOfferId:   parseInt(item.classicOfferId, 10),
              classicProductId: parseInt(item.classicProductId, 10),
              qty:              1,
              esd:              null,
              end:              null
            };

            // Vervang bestaande items met alleen het nieuwe item (Hunt = 1 item tegelijk)
            basket.items = [newItem];

            _l("PATCH body: " + JSON.stringify(basket).substring(0, 150) + "...");

            var patchHeaders = Object.assign({}, headers, { "Content-Type": "application/json" });

            // Stap 4: PATCH volledige basket terug
            fetch(BASKET_URL, {
              method:  "PATCH",
              headers: patchHeaders,
              body:    JSON.stringify(basket)
            })
            .then(function(r) {
              _l("PATCH status: " + r.status);
              if (!r.ok) {
                r.text().then(function(t) {
                  _l("PATCH fout: " + t.substring(0, 200));
                });
                chrome.storage.local.set({ fb_buying: false });
                _buyingInProgress = false;
              }
              // 200 → webRequest in worker detecteert PATCH → checkout redirect
            })
            .catch(function(e) {
              _l("PATCH error: " + e.message);
              chrome.storage.local.set({ fb_buying: false });
              _buyingInProgress = false;
            });
          })
          .catch(function(e) {
            _l("GET basket error: " + e.message);
            chrome.storage.local.set({ fb_buying: false });
            _buyingInProgress = false;
          });
      });
    });
  }

  // ── 3. Precisietimer: rapid poll vlak voor deal-einde ──────
  function _stopRapid() {
    if (_rapidTimer)     { clearInterval(_rapidTimer);  _rapidTimer = null; }
    if (_rapidScheduled) { clearTimeout(_rapidScheduled); _rapidScheduled = null; }
    _rapidActive = false;
  }

  function _startRapid() {
    if (_rapidActive) return;
    _rapidActive = true;
    _l("Rapid poll gestart (200ms)");
    _rapidTimer = setInterval(_poll, 200);
    // Max 30s rapid poll
    setTimeout(function() {
      if (_rapidActive) { _stopRapid(); _l("Rapid poll timeout"); }
    }, 30000);
  }

  function _scheduleRapid(endTimeStr) {
    if (!endTimeStr) return;
    var msLeft = new Date(endTimeStr) - Date.now();
    if (msLeft <= 0) { _startRapid(); return; }

    var triggerAt = msLeft - 8000; // 8s voor einde
    if (triggerAt <= 0) {
      _startRapid();
    } else {
      if (_rapidScheduled) clearTimeout(_rapidScheduled);
      _rapidScheduled = setTimeout(_startRapid, triggerAt);
      _l("Rapid poll scheduled in " + Math.round(triggerAt / 1000) + "s (deal eindigt in " + Math.round(msLeft / 1000) + "s)");
    }
  }

  // ── 4. Poll /event/events/live ─────────────────────────────
  function _poll() {
    fetch(LIVE_URL, { headers: IBEX })
      .then(function(r) { return r.json(); })
      .then(function(data) {
        var event = data && data.data && data.data.items && data.data.items[0];
        if (!event) return;
        var item = event.currentItem;
        if (!item) return;

        if (_lastItemId === null) {
          // Eerste poll: init
          _lastItemId = item.id;
          _l("Init: " + item.title + " | eindigt: " + item.end + " | " + Math.round((new Date(item.end) - Date.now()) / 1000) + "s resterend");
          _scheduleRapid(item.end);
          return;
        }

        if (item.id !== _lastItemId) {
          // Nieuw deal!
          _buyingInProgress = false; // reset voor nieuw item
          _lastItemId = item.id;
          var elapsed = Date.now(); // timing log
          _l("★ NIEUW DEAL via API: " + item.title);
          _tryBuy(item);
          _scheduleRapid(item.end);
          return;
        }

        // Zelfde deal — update rapid timing als we nog niet rapid pollen
        if (!_rapidActive) {
          _scheduleRapid(item.end);
        }
      })
      .catch(function() {});
  }

  // ── 5. Start ───────────────────────────────────────────────
  function _start() {
    _listenForBuyClick();
    _poll(); // meteen
    _normalTimer = setInterval(_poll, 2000);
    _l("Live polling gestart (elke 2s) + precisietimer actief.");
  }

  if (document.body) {
    _start();
  } else {
    document.addEventListener("DOMContentLoaded", _start);
  }

})();
