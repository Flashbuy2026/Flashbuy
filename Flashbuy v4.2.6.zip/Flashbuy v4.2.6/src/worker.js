// ══════════════════════════════════════════════════════════════
var FB_API_URL = "https://script.google.com/macros/s/AKfycbwVyhWEs9q7v78-prSD-IHNO5du8D-IJ0nU7EQjLMvejRgh6kO_ng2hGpEg0oIMZ6T9vg/exec";
// ══════════════════════════════════════════════════════════════

var FB_SECRET = "FB2026NovaDev";

// ── iBood API ──────────────────────────────────────────────────
var LIVE_URL   = "https://api.ibood.io/event/events/live";
var BASKET_URL = "https://api.ibood.io/basket/my-basket";
var IBEX_HEADERS = {
  "Accept":          "application/json, text/plain, */*",
  "Ibex-Language":   "nl",
  "Ibex-Shop-Id":    "52e47183-4a24-57fa-bef0-f82972e1f5ac",
  "Ibex-Tenant-Id":  "eafb3ef2-e1ba-4f01-b67a-b0447bea74eb"
};

// Bijhouden welk deal-item we al verwerkt hebben (per sessie)

// ── Capture ALLE headers + body van pagina's eigen basket PATCH ─
var fb_captured_auth = null;

chrome.webRequest.onBeforeSendHeaders.addListener(
  function(details) {
    if (!details.requestHeaders) return;
    // Sla ALLES op bij een PATCH (manuele klik van gebruiker)
    if (details.method === "PATCH") {
      var allHeaders = {};
      details.requestHeaders.forEach(function(h) {
        allHeaders[h.name] = h.value;
        if (h.name.toLowerCase() === "authorization") fb_captured_auth = h.value;
      });
      console.log("[FlashBuy worker] PATCH headers onderschept:", JSON.stringify(allHeaders));
      chrome.storage.local.set({ fb_ibood_patch_headers: JSON.stringify(allHeaders) });
    }
    // Altijd auth bewaren
    details.requestHeaders.forEach(function(h) {
      if (h.name.toLowerCase() === "authorization") {
        fb_captured_auth = h.value;
        chrome.storage.local.set({ fb_ibood_auth: h.value });
      }
    });
  },
  { urls: ["*://api.ibood.io/*"] },
  ["requestHeaders", "extraHeaders"]
);

chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    if (details.method !== "PATCH") return;
    if (!details.requestBody || !details.requestBody.raw) return;
    try {
      var raw = details.requestBody.raw[0].bytes;
      var bodyStr = new TextDecoder("utf-8").decode(raw);
      console.log("[FlashBuy worker] PATCH body onderschept:", bodyStr);
      chrome.storage.local.set({ fb_ibood_patch_body: bodyStr });
    } catch(e) {}
  },
  { urls: ["*://api.ibood.io/basket/my-basket*"] },
  ["requestBody"]
);

var lastBoxItemId = null;

// ── Licentie helpers ───────────────────────────────────────────
function fbDecrypt(encoded, key) {
  var secret = FB_SECRET + key;
  var bytes = atob(encoded);
  var result = "";
  for (var i = 0; i < bytes.length; i++) {
    result += String.fromCharCode(bytes.charCodeAt(i) ^ secret.charCodeAt(i % secret.length));
  }
  return JSON.parse(result);
}

function getDeviceId(callback) {
  chrome.storage.local.get(["fb_device_id"], function(d) {
    if (d.fb_device_id) {
      callback(d.fb_device_id);
    } else {
      var id = "FB-" + Date.now().toString(36) + "-" + Math.random().toString(36).substring(2, 10);
      chrome.storage.local.set({ fb_device_id: id }, function() {
        callback(id);
      });
    }
  });
}

function prefetchOps() {
  chrome.storage.sync.get(["fb_license"], function(cfg) {
    var key = (cfg.fb_license || "").toUpperCase();
    if (!key) return;

    getDeviceId(function(deviceId) {
      var url = FB_API_URL + "?key=" + encodeURIComponent(key) + "&action=payload";
      if (deviceId) url += "&device=" + encodeURIComponent(deviceId);

      fetch(url)
        .then(function(r) { return r.json(); })
        .then(function(res) {
          if (res.status === "valid" && res.ops) {
            try {
              var ops = fbDecrypt(res.ops, key);
              chrome.storage.local.set({
                fb_ops: JSON.stringify(ops),
                fb_valid: true,
                fb_expiry: res.expiry,
                fb_remaining: res.remaining,
                fb_lic_check_time: Date.now()
              });
              chrome.storage.sync.set({ fb_lic_data: JSON.stringify(res) });
            } catch (e) {}
          } else {
            chrome.storage.local.set({
              fb_valid: false,
              fb_lic_check_time: Date.now()
            });
            chrome.storage.local.remove(["fb_ops"]);
            chrome.storage.sync.set({ fb_lic_data: JSON.stringify(res || { status: "invalid" }) });
          }
        })
        .catch(function() {});
    });
  });
}

// ── Box Mode: fetch actieve deal van iBood ─────────────────────
async function fetchLiveDeal() {
  try {
    var r = await fetch(LIVE_URL, {
      method: "GET",
      credentials: "include",
      headers: IBEX_HEADERS
    });
    if (!r.ok) return null;
    var data = await r.json();
    var event = data && data.data && data.data.items && data.data.items[0];
    return event ? event.currentItem : null;
  } catch (e) {
    return null;
  }
}

// ── Box Mode: klik koopknop via executeScript ─────────────────
// Laat de pagina's eigen code de PATCH uitvoeren — geen auth/body issues.
// Worker detecteert de PATCH via webRequest en redirectt naar checkout.
function addToBasketViaTab(tabId, item) {
  if (!tabId) {
    console.log("[FlashBuy box] Geen tabId beschikbaar");
    return;
  }

  console.log("[FlashBuy box] Koopknop klikken voor:", item.title);

  // Zet fb_buying vlag VÓÓR de klik zodat de webRequest listener het oppikt
  chrome.storage.local.set({ fb_buying: true, fb_buying_time: Date.now() });

  chrome.scripting.executeScript({
    target: { tabId: tabId },
    func: function() {
      // Zoek de koopknop op de Hunt-pagina
      var selectors = [
        "button[class*=\'btnMain\']",
        "button[class*=\'Offer_btn\']",
        ".btnMain",
        "button.orange"
      ];

      var btn = null;

      // Probeer CSS selectors
      for (var s = 0; s < selectors.length; s++) {
        try {
          btn = document.querySelector(selectors[s]);
          if (btn) break;
        } catch(e) {}
      }

      // Fallback: scan alle buttons op tekst
      if (!btn) {
        var allBtns = document.querySelectorAll("button, a[role=\'button\']");
        for (var i = 0; i < allBtns.length; i++) {
          var txt = (allBtns[i].textContent || "").toLowerCase().trim();
          if (txt === "ik neem er 1!" || txt === "ik neem er 1" || txt === "nu afrekenen") {
            btn = allBtns[i];
            break;
          }
        }
      }

      if (btn) {
        console.log("[FlashBuy injected] ✓ Koopknop gevonden:", btn.textContent.trim(), "— klikken!");
        btn.click();
        return true;
      } else {
        console.log("[FlashBuy injected] ✗ Koopknop niet gevonden op pagina");
        return false;
      }
    },
    args: []
  }).catch(function(e) {
    console.log("[FlashBuy box] executeScript fout:", e.message);
    // Fallback: reset fb_buying als klik mislukt
    chrome.storage.local.set({ fb_buying: false });
  });
}

// ── Box Mode handler: aangeroepen bij hash-change signaal ──────
async function handleBoxMode(tabId) {
  chrome.storage.local.get(["fb_paused", "fb_box_mode", "fb_box_filter"], async function(d) {
    console.log("[FlashBuy box] FB_HASH_CHANGE — paused:" + !!d.fb_paused + " boxMode:" + !!d.fb_box_mode);
    if (d.fb_paused || !d.fb_box_mode) return;

    var item = await fetchLiveDeal();
    if (!item) return;
    if (item.soldOut) return;
    if (item.id === lastBoxItemId) return; // Al verwerkt

    lastBoxItemId = item.id;

    // ── Slug/titel filter ──────────────────────────────────
    var filter = (d.fb_box_filter || "").toLowerCase().trim();
    if (filter) {
      var slugMatch  = (item.slug  || "").toLowerCase().indexOf(filter) !== -1;
      var titleMatch = (item.title || "").toLowerCase().indexOf(filter) !== -1;
      if (!slugMatch && !titleMatch) {
        console.log("[FlashBuy box] Overgeslagen (filter '" + filter + "'): " + item.title);
        return;
      }
    }

    console.log("[FlashBuy box] ✓ Filter OK — PATCH via tab:", item.title);
    addToBasketViaTab(tabId, item); // Resultaat komt terug via FB_BASKET_OK message
  });
}

// ── Message listener ──────────────────────────────────────────
// Content script (quicknav.js) handelt box mode af (polling + PATCH).
// Worker beheert enkel nog checkout redirect via webRequest.
chrome.runtime.onMessage.addListener(function(msg, sender) {
  if (msg.type === "FB_BASKET_OK") {
    chrome.action.setBadgeText({ text: "✓" });
    chrome.action.setBadgeBackgroundColor({ color: "#2ecc71" });
    setTimeout(function() { chrome.action.setBadgeText({ text: "" }); }, 4000);
  }

  // Content script vraagt om PATCH via executeScript (page context = juiste Origin)
  if (msg.type === "FB_DO_PATCH" && msg.item && sender.tab) {
    var tabId = sender.tab.id;
    var item  = msg.item;

    chrome.storage.local.get(["fb_ibood_patch_headers"], function(d) {
      // Gebruik gecaptureerde headers van pagina's eigen PATCH; fallback naar bekende waarden
      var captured = {};
      try { captured = JSON.parse(d.fb_ibood_patch_headers || "{}"); } catch(e) {}

      // Zoek Authorization ongeacht hoofdletters
      var authToken = null;
      Object.keys(captured).forEach(function(k) {
        if (k.toLowerCase() === "authorization") authToken = captured[k];
      });

      var patchHeaders = {
        "Content-Type":   "application/json",
        "Accept":         "application/json, text/plain, */*",
        "Ibex-Language":  captured["Ibex-Language"]  || "nl",
        "Ibex-Shop-Id":   captured["Ibex-Shop-Id"]   || "52e47183-4a24-57fa-bef0-f82972e1f5ac",
        "Ibex-Tenant-Id": captured["Ibex-Tenant-Id"] || "eafb3ef2-e1ba-4f01-b67a-b0447bea74eb"
      };
      if (authToken) {
        patchHeaders["Authorization"] = authToken;
      }

      console.log("[FlashBuy worker] FB_DO_PATCH voor:", item.title);
      console.log("[FlashBuy worker] Auth aanwezig:", !!authToken);
      console.log("[FlashBuy worker] Headers:", JSON.stringify(patchHeaders));

      chrome.scripting.executeScript({
        target: { tabId: tabId },
        func: function(url, body, headers) {
          // Draait in page context: Origin = https://www.ibood.com, geen credentials nodig
          console.log("[FlashBuy injected] PATCH sturen:", JSON.stringify(body));
          fetch(url, {
            method:  "PATCH",
            headers: headers,
            body:    JSON.stringify(body)
          })
          .then(function(r) {
            console.log("[FlashBuy injected] PATCH status:", r.status);
            if (r.ok) {
              chrome.runtime.sendMessage({ type: "FB_BASKET_OK" });
            } else {
              r.text().then(function(t) {
                console.log("[FlashBuy injected] PATCH fout:", r.status, t.substring(0, 300));
                // Reset zodat we opnieuw kunnen proberen
                chrome.runtime.sendMessage({ type: "FB_PATCH_FAILED" });
              });
            }
          })
          .catch(function(e) {
            console.log("[FlashBuy injected] PATCH error:", e.message);
            chrome.runtime.sendMessage({ type: "FB_PATCH_FAILED" });
          });
        },
        args: [
          "https://api.ibood.io/basket/my-basket",
          { offerId: item.offerId, offerItemId: item.offerItemId, classicOfferId: item.classicOfferId, qty: 1 },
          patchHeaders
        ]
      }).catch(function(e) {
        console.log("[FlashBuy worker] executeScript fout:", e.message);
      });
    });
  }

  if (msg.type === "FB_PATCH_FAILED") {
    chrome.storage.local.set({ fb_buying: false });
  }
});

// ── Lifecycle ──────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(function() {
  chrome.storage.sync.set({ fb_api: FB_API_URL, fb_method: "PAYPAL" });
  chrome.storage.local.remove(["fb_lic_check_time"]);
  setTimeout(prefetchOps, 2000);
});

chrome.runtime.onStartup.addListener(function() {
  chrome.storage.sync.set({ fb_api: FB_API_URL });
  chrome.storage.local.remove(["fb_lic_check_time"]);
  chrome.storage.sync.get(["fb_paused", "fb_box_mode"], function(d) {
    chrome.storage.local.set({
      fb_paused:   !!d.fb_paused,
      fb_box_mode: !!d.fb_box_mode
    });
  });
  prefetchOps();
});

// ── QuickNav: detecteer add-to-cart PATCH via webRequest ──────
chrome.webRequest.onCompleted.addListener(
  function(details) {
    if (details.method !== "PATCH") return;
    if (details.url.indexOf("api.ibood.io/basket/my-basket") === -1) return;
    if (details.statusCode < 200 || details.statusCode >= 300) return;

    chrome.storage.local.get(["fb_paused", "fb_buying", "fb_buying_time"], function(d) {
      if (d.fb_paused) return;

      var buyingRecent = d.fb_buying &&
        d.fb_buying_time &&
        (Date.now() - d.fb_buying_time) < 10000;

      if (!buyingRecent) return;

      chrome.storage.local.set({ fb_buying: false });

      setTimeout(function() {
        chrome.tabs.get(details.tabId, function(tab) {
          if (!tab || !tab.url) return;
          if (tab.url.indexOf("/basket") !== -1 ||
              tab.url.indexOf("/checkout") !== -1) return;
          var isBE = tab.url.indexOf("/s-be") !== -1;
          var checkoutUrl = isBE
            ? "https://www.ibood.com/basket/nl/s-be/checkout"
            : "https://www.ibood.com/basket/nl/s-nl/checkout";
          chrome.tabs.update(details.tabId, { url: checkoutUrl });
        });
      }, 300);
    });
  },
  { urls: ["*://api.ibood.io/basket/my-basket*"] }
);

chrome.tabs.onUpdated.addListener(function(tabId, info, tab) {
  if (!tab.url || tab.url.indexOf("ibood.com") === -1) return;

  if (tab.url.indexOf("/basket/") !== -1 &&
      tab.url.indexOf("/checkout") === -1 &&
      info.status === "complete") {
    chrome.storage.local.get(["fb_paused"], function(d) {
      if (d.fb_paused) return;
      setTimeout(function() {
        var isBE = tab.url.indexOf("/s-be") !== -1;
        var checkoutUrl = isBE
          ? "https://www.ibood.com/basket/nl/s-be/checkout"
          : "https://www.ibood.com/basket/nl/s-nl/checkout";
        chrome.tabs.update(tabId, { url: checkoutUrl });
      }, 300);
    });
  }

  if (tab.url.indexOf("/checkout") !== -1 && info.status === "complete") {
    chrome.storage.local.get(["fb_valid", "fb_ops"], function(d) {
      if (d.fb_valid && d.fb_ops) {
        chrome.scripting.executeScript({ target: { tabId: tabId }, files: ["src/autocheckout.js"] })
          .catch(function(e) {});
      } else {
        prefetchOps();
        setTimeout(function() {
          chrome.scripting.executeScript({ target: { tabId: tabId }, files: ["src/autocheckout.js"] })
            .catch(function(e) {});
        }, 3000);
      }
    });
  }
});
