// FlashBuy – config.js (popup logic v4.0.0)

const KEYS = {
  email:   "fb_email",
  pass:    "fb_pass",
  auto:    "fb_autologin",
  method:  "fb_method",
  license: "fb_license",
  licData: "fb_lic_data",
  api:     "fb_api",
  paused:  "fb_paused",
  boxMode:   "fb_box_mode",
  boxFilter: "fb_box_filter",
};

const EMAIL      = "Flashbuy.novadevlabs@gmail.com";
const API_URL    = "https://script.google.com/macros/s/AKfycbwVyhWEs9q7v78-prSD-IHNO5du8D-IJ0nU7EQjLMvejRgh6kO_ng2hGpEg0oIMZ6T9vg/exec";
const PAYPAL_LINK = "https://www.paypal.com/paypalme/Novadevlabs";
const X_LINK     = "https://x.com/Flashbuy2026";

async function getDeviceId() {
  return new Promise(function(resolve) {
    chrome.storage.local.get(["fb_device_id"], function(d) {
      if (d.fb_device_id) {
        resolve(d.fb_device_id);
      } else {
        var id = "FB-" + Date.now().toString(36) + "-" + Math.random().toString(36).substring(2, 10);
        chrome.storage.local.set({ fb_device_id: id }, function() { resolve(id); });
      }
    });
  });
}

document.addEventListener("DOMContentLoaded", () => {
  const $ = (id) => document.getElementById(id);
  const dot = $("statusDot"), statusText = $("statusText");
  const licSection = $("licenseSection"), mainSection = $("mainSection");

  // ── Licentie laden (max 1x per dag, of na server-update) ──
  chrome.storage.sync.get(Object.values(KEYS), function(d) {
    chrome.storage.local.get(["fb_lic_check_time", "fb_valid"], async function(lc) {
      var lastCheck = lc.fb_lic_check_time || 0;
      var now = Date.now();
      var dayMs = 24 * 60 * 60 * 1000;

      if (d[KEYS.license] && d[KEYS.api]) {
        var needsCheck = (now - lastCheck > dayMs) || (lc.fb_valid === false);

        if (needsCheck) {
          var deviceId = await getDeviceId();
          checkLicense(d[KEYS.api], d[KEYS.license], deviceId, function(result) {
            chrome.storage.local.set({ fb_lic_check_time: now });
            if (result && result.status === "valid") {
              chrome.storage.sync.set({ [KEYS.licData]: JSON.stringify(result) });
              showMain(d, result);
            } else if (result && result.status === "expired") {
              chrome.storage.local.set({ fb_valid: false });
              chrome.storage.local.remove(["fb_ops"]);
              chrome.storage.sync.set({ [KEYS.licData]: JSON.stringify(result) });
              showLicense(); setStatus("off", "LICENTIE VERLOPEN");
              showToast("licToast", "Licentie verlopen. Koop een nieuwe key.", "err");
            } else if (result && result.status === "device_mismatch") {
              chrome.storage.local.set({ fb_valid: false });
              chrome.storage.local.remove(["fb_ops"]);
              chrome.storage.sync.set({ [KEYS.licData]: JSON.stringify(result) });
              showLicense(); setStatus("off", "ANDER APPARAAT");
              showToast("licToast", "Deze key is al actief op een ander apparaat.", "err");
            } else {
              chrome.storage.local.set({ fb_valid: false });
              chrome.storage.local.remove(["fb_ops"]);
              showLicense(); setStatus("off", "ONGELDIGE LICENTIE");
            }
          });
        } else {
          try {
            var ld = d[KEYS.licData] ? JSON.parse(d[KEYS.licData]) : null;
            if (ld && ld.status === "valid" && lc.fb_valid !== false) {
              showMain(d, ld);
            } else {
              showLicense(); setStatus("off", "GEEN LICENTIE");
            }
          } catch (e) {
            showLicense(); setStatus("off", "GEEN LICENTIE");
          }
        }
      } else {
        showLicense(); setStatus("off", "GEEN LICENTIE");
      }
    });
  });

  // ── Activeren ─────────────────────────────────────────────
  $("activateBtn").addEventListener("click", async () => {
    const key = $("licenseKey").value.trim().toUpperCase();
    if (!key) { showToast("licToast", "Voer een licentiesleutel in.", "err"); return; }
    $("activateBtn").textContent = "Controleren…";
    $("activateBtn").disabled = true;
    var deviceId = await getDeviceId();
    checkLicense(API_URL, key, deviceId, function(result) {
      $("activateBtn").textContent = "Activeren";
      $("activateBtn").disabled = false;
      if (!result) { showToast("licToast", "Server niet bereikbaar.", "err"); return; }
      if (result.status === "valid") {
        chrome.storage.sync.set({
          [KEYS.license]: key, [KEYS.licData]: JSON.stringify(result),
          [KEYS.method]: "PAYPAL", [KEYS.api]: API_URL,
        }, function() {
          chrome.storage.local.set({ fb_lic_check_time: Date.now() });
          chrome.storage.sync.get(Object.values(KEYS), (d2) => showMain(d2, result));
        });
      } else if (result.status === "expired") {
        showToast("licToast", "Deze licentie is verlopen.", "err");
      } else if (result.status === "device_mismatch") {
        showToast("licToast", "Deze key is al actief op een ander apparaat.", "err");
      } else {
        showToast("licToast", "Ongeldige licentiesleutel.", "err");
      }
    });
  });

  // ── Opslaan ───────────────────────────────────────────────
  $("saveBtn").addEventListener("click", () => {
    var filterVal = $("boxFilterInput").value.toLowerCase().trim();
    chrome.storage.sync.set({
      [KEYS.email]:     $("email").value.trim(),
      [KEYS.pass]:      $("pass").value,
      [KEYS.auto]:      $("autoLogin").checked,
      [KEYS.method]:    "PAYPAL",
      [KEYS.boxFilter]: filterVal,
    }, () => {
      chrome.storage.local.set({ fb_box_filter: filterVal });
      showToast("toast", "✓ OPGESLAGEN", "ok");
    });
  });

  // ── Reset hunt stats ──────────────────────────────────────
  $("resetStatsBtn").addEventListener("click", function() {
    if (confirm("Statistieken wissen voor de nieuwe Hunt?")) {
      chrome.storage.local.set({ fb_stats: JSON.stringify({ deals: 0, fastest: 99, total: 0 }) }, function() {
        $("huntStats").style.display = "none";
        showToast("toast", "✓ Statistieken gereset", "ok");
      });
    }
  });

  // ── Pause toggle ──────────────────────────────────────────
  $("pauseInput").addEventListener("change", function(e) {
    var paused = e.target.checked;
    chrome.storage.sync.set({ [KEYS.paused]: paused });
    chrome.storage.local.set({ fb_paused: paused }, function() {
      _updateStatus();
    });
  });

  // ── Box Mode toggle ───────────────────────────────────────
  $("boxModeInput").addEventListener("change", function(e) {
    var boxMode = e.target.checked;
    chrome.storage.sync.set({ [KEYS.boxMode]: boxMode });
    chrome.storage.local.set({ fb_box_mode: boxMode }, function() {
      _updateStatus();
      if (boxMode) {
        showToast("toast", "⚡ Box Mode ingeschakeld — auto-detectie actief", "ok");
      }
    });
  });

  // ── Box filter input ──────────────────────────────────────
  $("boxFilterInput").addEventListener("input", function(e) {
    var val = e.target.value.toLowerCase().trim();
    chrome.storage.sync.set({ [KEYS.boxFilter]: val });
    chrome.storage.local.set({ fb_box_filter: val });
  });

  // ── Licentie wijzigen ─────────────────────────────────────
  document.getElementById("changeLicBtn").addEventListener("click", () => showLicense());

  // ── Links ─────────────────────────────────────────────────
  document.getElementById("contactEmail").href = "mailto:" + EMAIL;
  document.getElementById("xLink").href = X_LINK;
  var buyBtn = document.getElementById("buyLicBtn");
  if (buyBtn) buyBtn.href = PAYPAL_LINK;

  // ── Debug Report ──────────────────────────────────────────
  var debugBtn = document.getElementById("debugBtn");
  if (debugBtn) {
    debugBtn.addEventListener("click", function() {
      var cr = $("checkResult");
      cr.style.display = "block";
      cr.innerHTML = '<span class="info">⏳ Rapport genereren…</span>';

      chrome.storage.sync.get([KEYS.license, KEYS.licData, KEYS.api, KEYS.method], function(syncData) {
        chrome.storage.local.get(["fb_ops", "fb_valid", "fb_stats", "fb_device_id", "fb_box_mode"], function(localData) {
          var licStatus = "geen", licExpiry = "-", licRemaining = "-";
          if (syncData[KEYS.licData]) {
            try {
              var ld = JSON.parse(syncData[KEYS.licData]);
              licStatus = ld.status || "onbekend";
              licExpiry = ld.expiry || "-";
              licRemaining = ld.remaining || "-";
            } catch (e) {}
          }

          var opsVersion = "-";
          if (localData.fb_ops) {
            try { opsVersion = "v" + JSON.parse(localData.fb_ops).version; } catch (e) {}
          }

          var stats = { deals: 0, fastest: 99, total: 0 };
          if (localData.fb_stats) {
            try { stats = JSON.parse(localData.fb_stats); } catch (e) {}
          }

          var lines = [
            "FlashBuy Debug Rapport",
            "─────────────────────",
            "Extensie: v4.2.0",
            "Selector Pack: " + opsVersion,
            "Apparaat: " + (localData.fb_device_id || "onbekend"),
            "─────────────────────",
            "Licentie: " + licStatus,
            "Vervalt: " + licExpiry,
            "Resterend: " + licRemaining + "d",
            "─────────────────────",
            "Cache: " + (localData.fb_valid ? "geldig" : "ongeldig"),
            "Betaalmethode: " + (syncData[KEYS.method] || "geen"),
            "Box Mode: " + (localData.fb_box_mode ? "AAN" : "UIT"),
            "Box Filter: " + (localData.fb_box_filter || "(geen)"),
            "─────────────────────",
            "Deals gescoord: " + stats.deals,
            "Snelste: " + (stats.fastest < 99 ? stats.fastest.toFixed(3) + "s" : "-"),
            "Laatste: " + (stats.lastMs ? (stats.lastMs / 1000).toFixed(3) + "s" : "-"),
            "─────────────────────",
            "Tijdstip: " + new Date().toISOString(),
          ];

          var report = lines.join("\n");
          cr.innerHTML = '<pre style="margin:0;white-space:pre-wrap;color:#aaa;font-size:9.5px;">' + report + '</pre>' +
            '<button id="copyReport" style="margin-top:8px;padding:6px 12px;background:#FF6B35;color:#fff;border:none;border-radius:6px;font-size:10px;cursor:pointer;font-family:inherit;">📋 Kopieer rapport</button>';

          document.getElementById("copyReport").addEventListener("click", function() {
            navigator.clipboard.writeText(report).then(function() {
              document.getElementById("copyReport").textContent = "✅ Gekopieerd!";
              setTimeout(function() { document.getElementById("copyReport").textContent = "📋 Kopieer rapport"; }, 2000);
            });
          });
        });
      });
    });
  }

  // ── Hunt stats laden ──────────────────────────────────────
  chrome.storage.local.get(["fb_stats"], function(d) {
    if (d.fb_stats) {
      try {
        var stats = JSON.parse(d.fb_stats);
        var el = $("huntStats");
        if (el && stats.deals > 0) {
          el.style.display = "block";
          $("statDeals").textContent = stats.deals;
          $("statFastest").textContent = stats.fastest < 99 ? stats.fastest.toFixed(3) + "s" : "-";
          $("statAvg").textContent = (stats.total / stats.deals).toFixed(3) + "s";
        }
      } catch (e) {}
    }
  });

  // ── Helpers ───────────────────────────────────────────────
  function showLicense() {
    licSection.classList.add("active");
    mainSection.classList.remove("active");
    $("pauseToggle").style.display = "none";
  }

  function showMain(data, lr) {
    licSection.classList.remove("active");
    mainSection.classList.add("active");
    if (data[KEYS.email]) $("email").value = data[KEYS.email];
    if (data[KEYS.pass])  $("pass").value  = data[KEYS.pass];
    if (data[KEYS.auto])  $("autoLogin").checked = true;
    $("licInfo").innerHTML = '🔑 Licentie: <span class="val">ACTIEF</span><br>📅 Geldig tot: <span class="exp">' + lr.expiry + '</span><br>⏳ Nog <span class="exp">' + lr.remaining + ' dagen</span>';

    $("pauseToggle").style.display = "block";

    var isPaused = !!data[KEYS.paused];
    $("pauseInput").checked = isPaused;
    chrome.storage.local.set({ fb_paused: isPaused });

    var isBoxMode = !!data[KEYS.boxMode];
    $("boxModeInput").checked = isBoxMode;
    chrome.storage.local.set({ fb_box_mode: isBoxMode });

    // Gebruik opgeslagen waarde; "de-box" alleen als er nog nooit iets opgeslagen is
    var boxFilter = (data[KEYS.boxFilter] !== undefined && data[KEYS.boxFilter] !== null)
      ? data[KEYS.boxFilter]
      : "de-box";
    $("boxFilterInput").value = boxFilter;
    chrome.storage.local.set({ fb_box_filter: boxFilter });

    _updateStatus();
  }

  function _updateStatus() {
    chrome.storage.local.get(["fb_paused", "fb_box_mode"], function(d) {
      if (d.fb_paused) {
        setStatus("paused", "PAUSED");
      } else if (d.fb_box_mode) {
        setStatus("box", "BOX MODE — ARMED");
      } else {
        setStatus("", "ARMED — PAYPAL");
      }
    });
  }

  function setStatus(cls, text) {
    dot.className = "status-dot" + (cls ? " " + cls : "");
    statusText.textContent = text;
  }

  function showToast(id, msg, type) {
    var el = $(id);
    el.textContent = msg;
    el.className = "toast " + type;
    el.style.opacity = "1";
    if (type === "ok") setTimeout(function() { el.style.opacity = "0"; }, 2500);
  }

  function checkLicense(api, key, deviceId, callback) {
    try {
      var url = api + "?key=" + encodeURIComponent(key);
      if (deviceId) url += "&device=" + encodeURIComponent(deviceId);
      fetch(url)
        .then(function(r) { return r.json(); })
        .then(function(res) { callback(res); })
        .catch(function(e) { callback(null); });
    } catch (e) {
      callback(null);
    }
  }
});
