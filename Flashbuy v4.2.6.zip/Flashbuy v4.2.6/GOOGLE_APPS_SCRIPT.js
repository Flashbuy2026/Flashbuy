// ══════════════════════════════════════════════════════════════════
// FlashBuy — Google Apps Script (Licentieverificatie + Apparaatlock)
// ══════════════════════════════════════════════════════════════════
//
// Google Sheet kolommen:
//   A1: key     B1: email     C1: expiry     D1: device
//
// Installatie: zie LEES_MIJ_EERST.txt
// ══════════════════════════════════════════════════════════════════

var PAYLOAD_SECRET = "FB2026NovaDev";

function doGet(e) {
  var inputKey    = (e.parameter.key || "").trim().toUpperCase();
  var action      = (e.parameter.action || "check").trim();
  var inputDevice = (e.parameter.device || "").trim();

  if (!inputKey) {
    return respond({ status: "error", message: "Geen key." });
  }

  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var data  = sheet.getDataRange().getValues();

  for (var i = 1; i < data.length; i++) {
    var storedKey = (data[i][0] || "").toString().trim().toUpperCase();

    if (storedKey === inputKey) {
      var email       = data[i][1] || "";
      var expiry      = data[i][2] || "";
      var storedDevice = (data[i][3] || "").toString().trim();

      // Parse vervaldatum
      var expiryDate;
      if (expiry instanceof Date) {
        expiryDate = expiry;
      } else {
        expiryDate = new Date(expiry);
      }

      if (isNaN(expiryDate.getTime())) {
        return respond({ status: "error", message: "Ongeldige datum." });
      }

      var now = new Date();
      if (now > expiryDate) {
        return respond({ status: "expired", expiry: fmt(expiryDate) });
      }

      // ── Apparaat-check ─────────────────────────────────────────
      if (inputDevice) {
        if (!storedDevice) {
          // Eerste activatie: sla apparaat-ID op
          sheet.getRange(i + 1, 4).setValue(inputDevice);
        } else if (storedDevice !== inputDevice) {
          // Ander apparaat: blokkeer
          return respond({ 
            status: "device_mismatch", 
            message: "Deze licentie is al geactiveerd op een ander apparaat." 
          });
        }
        // Zelfde apparaat: doorgaan
      }

      // Key is geldig
      if (action === "payload") {
        return respond({
          status: "valid",
          expiry: fmt(expiryDate),
          remaining: Math.ceil((expiryDate - now) / 86400000),
          ops: encryptPayload(getCheckoutOps(), inputKey)
        });
      } else {
        return respond({
          status: "valid",
          expiry: fmt(expiryDate),
          remaining: Math.ceil((expiryDate - now) / 86400000)
        });
      }
    }
  }

  return respond({ status: "invalid", message: "Onbekende key." });
}

function getCheckoutOps() {
  return {
    version: 3,
    delivery: [
      'div[data-testid="box-deliver-to-delivery-address"]',
      'div[data-testid="txt-deliver-to-delivery-address"]'
    ],
    deliveryFallback: ["afleveradres", "bezorg op"],
    payment: {
      PAYPAL:     'div[data-testid="box-method-paypal"]',
      BANCONTACT: 'div[data-testid="box-method-bancontact"]',
      CC:         'div[data-testid="box-method-creditcard"]',
      KLARNA:     'div[data-testid="box-method-klarna"]'
    },
    submit: 'button[data-testid="btn-order-and-pay"]',
    timing: { init: 400, step: 150, preSubmit: 300 }
  };
}

function encryptPayload(obj, key) {
  var json = JSON.stringify(obj);
  var secret = PAYLOAD_SECRET + key;
  var result = [];
  for (var i = 0; i < json.length; i++) {
    result.push(json.charCodeAt(i) ^ secret.charCodeAt(i % secret.length));
  }
  return Utilities.base64Encode(result);
}

function fmt(d) {
  return d.getFullYear() + "-" + ("0"+(d.getMonth()+1)).slice(-2) + "-" + ("0"+d.getDate()).slice(-2);
}

function respond(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
